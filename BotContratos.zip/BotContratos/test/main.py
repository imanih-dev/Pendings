# app/main.py
import uvicorn
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from typing import Dict, Any, List, Optional
import os
from datetime import date
from pydantic import BaseModel, Field

# Define un modelo de datos para las filas de la tabla
class ContractRow(BaseModel):
    code: str = Field(..., description="Código del contrato.")
    name: str = Field(..., description="Nombre completo del contratista.")
    position: str = Field(..., description="Cargo del contratista.")
    entry_date: date = Field(..., description="Fecha de ingreso.")
    contract: str = Field(..., description="Tipo de contrato.")
    to: str = Field(..., description="Correos de destino.")
    cc: str = Field(..., description="Correos con copia.")

# Clase para manejar el estado de la aplicación de forma "saludable"
class AppState:
    def __init__(self):
        # Datos de ejemplo para las cuentas de correo.
        self.accounts: List[str] = ["contratos@empresa.com", "recursos_humanos@empresa.com"]
        # Simulamos que las filas de la tabla se almacenan aquí
        self.generated_rows: List[Dict[str, Any]] = []

    def get_accounts(self) -> List[str]:
        return self.accounts

    def add_account(self, email: str):
        self.accounts.append(email)

    def set_rows(self, rows: List[Dict[str, Any]]):
        self.generated_rows = rows

    def get_rows(self) -> List[Dict[str, Any]]:
        return self.generated_rows

# Define el directorio para las plantillas y los archivos estáticos
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")

# Inicializa la aplicación FastAPI
app = FastAPI()

# Asignamos el objeto de estado a la aplicación.
# Esto es un patrón común de FastAPI para evitar variables globales.
app.state = AppState()

templates = Jinja2Templates(directory=TEMPLATES_DIR)

# Crea directorios si no existen
os.makedirs(TEMPLATES_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)

# Define el contenido completo del archivo HTML, incluyendo el modal
html_content = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bot de Contratos</title>
    <meta name="api-base" content="{{ api_base }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        html, body { height:100%; background:#f0f2f5; }
        .header-bg { background:#002244; color:#fff; }
        .card-custom { background:#fff; border-radius:.5rem; box-shadow:0 .5rem 1rem rgba(0,0,0,.05); padding:1.5rem; }
        .border-left-blue { border-left:4px solid #2646be; }
        .border-left-green { border-left:4px solid #94c131; }
        .border-left-primary { border-left:4px solid #0d6efd; }
        .dropzone { border:2px dashed #ccc; border-radius:.5rem; padding:2rem; text-align:center; color:#6c757d; cursor:pointer; }
        .dropzone:hover { border-color:#0d6efd; }
        .btn-green-custom { background:#5a7a1f; color:#fff; font-weight:600; }
        .btn-green-custom:hover { background:#4a6a1a; }
        .btn-orange-custom { background:#cc7a15; color:#fff; font-weight:600; }
        .btn-orange-custom:hover { background:#b86d13; }
        .table-empty-message { color:#6c757d; }
        /* Nuevas reglas para la tabla */
        .table-responsive {
            max-height: calc(100vh - 350px); /* Ajusta la altura de la tabla para que no se desborde */
        }
        .table-responsive thead th {
            font-weight: 600;
        }
        .table-responsive td, .table-responsive th {
            white-space: nowrap; /* Evita que el texto salte de línea */
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/static/config.js"></script>
</head>
<body>
<div class="h-100 d-flex flex-column">
    <header class="header-bg">
        <div class="container-xl py-3 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-3">
                <i class="bi bi-file-text-fill fs-1"></i>
                <div>
                    <h1 class="h4 mb-0">Bot de Contratos</h1>
                    <p class="mb-0 text-white-50">versión 1.0.0</p>
                </div>
            </div>
            <div class="d-flex align-items-center gap-2 bg-white bg-opacity-10 px-3 py-1 rounded-pill">
                <i class="bi bi-person-fill"></i>
                <span id="recordCount">0 contratos cargados</span>
            </div>
        </div>
    </header>
    <main class="flex-grow-1 container-xl py-4">
        <div class="row h-100 g-4">
            <div class="col-lg-3 d-flex flex-column gap-4">
                <div class="card-custom border-left-blue">
                    <h5 class="text-primary mb-3"><i class="bi bi-cloud-arrow-up me-2"></i>Cargar Documento</h5>
                    <label class="dropzone d-block">
                        <input type="file" accept=".docx" class="d-none" id="fileInput">
                        <i class="bi bi-cloud-upload fs-1"></i>
                        <p class="fw-bold mt-2 mb-0">Arrastra o selecciona el archivo .docx aquí</p>
                    </label>
                </div>
                <div class="card-custom border-left-green flex-grow-1 d-flex flex-column">
                    <h5 class="text-success mb-3"><i class="bi bi-database me-2"></i>Acciones</h5>
                    <!-- Botón para añadir una nueva cuenta de correo que abre el modal -->
                    <button id="btnAddAccount" class="btn btn-green-custom w-75 mx-auto py-2 mb-3" data-bs-toggle="modal" data-bs-target="#addAccountModal">
                        <i class="bi bi-person-add me-2"></i>Añadir Nueva Cuenta
                    </button>
                    <p class="fw-light mt-1 mb-1">Elija la cuenta de correo que enviará los correos.</p>
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <select id="emailAccountSelector" class="form-select form-select-sm w-auto">
                            <!-- Las opciones se cargarán con JavaScript -->
                        </select>
                    </div>
                    <!-- Separador y botón de enviar correos -->
                    <hr class="my-3">
                    <p class="fw-light mt-1 mb-1">Presione el botón para enviar correos.</p>
                    <div class="d-grid gap-3 mt-2">
                        <button id="btnSendEmails" class="btn btn-orange-custom w-75 mx-auto py-2">
                            <i class="bi bi-envelope-fill me-2"></i>Enviar Correos
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 d-flex flex-column">
                <div class="card-custom border-left-primary flex-grow-1 d-flex flex-column">
                    <h5 class="text-primary mb-3"><i class="bi bi-people-fill me-2"></i>Consolidado</h5>
                    <div class="table-container bg-light p-2 rounded-3 border">
                        <div class="table-responsive">
                            <table id="consolidatedTable" class="table table-striped table-hover m-0 align-middle">
                                <thead class="sticky-top bg-light">
                                    <tr>
                                        <th class="text-center">Código</th>
                                        <th class="text-center">Nombres y Apellidos</th>
                                        <th class="text-center">Cargo</th>
                                        <th class="text-center">Fecha de Ingreso</th>
                                        <th class="text-center">Contrato</th>
                                        <th class="text-center">Correos (Para)</th>
                                        <th class="text-center">Correos (Copia)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Aquí se cargará el contenido de la tabla dinámicamente -->
                                    <tr>
                                        <td colspan="7" class="table-empty-message text-center">
                                            No se ha cargado el consolidado.<br>
                                            Seleccione un archivo Word para empezar.
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Modal para añadir nueva cuenta -->
<div class="modal fade" id="addAccountModal" tabindex="-1" aria-labelledby="addAccountModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addAccountModalLabel">Añadir Nueva Cuenta de Correo</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="addAccountForm">
          <div class="mb-3">
            <label for="accountIdentifier" class="form-label">Nombre Identificador</label>
            <input type="text" class="form-control" id="accountIdentifier" required>
          </div>
          <div class="mb-3">
            <label for="accountEmail" class="form-label">Dirección de Correo Electrónico</label>
            <input type="email" class="form-control" id="accountEmail" required>
          </div>
          <div class="mb-3">
            <label for="accountPassword" class="form-label">Contraseña de Aplicación</label>
            <input type="password" class="form-control" id="accountPassword" required>
          </div>
          <div class="mb-3">
            <label for="accountSignature" class="form-label">Firma</label>
            <select class="form-select" id="accountSignature">
              <option value="" selected>Sin firma</option>
              <option value="firma_oficial">Firma Oficial</option>
              <option value="firma_personal">Firma Personal</option>
            </select>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-success" form="addAccountForm" id="btnSubmitAccount">Guardar Cuenta</button>
      </div>
    </div>
  </div>
</div>

<script>
    function base() {
        const q = new URLSearchParams(location.search).get("api");
        if (q) return q.replace(/\/+$/,'');
        if (window.__API_BASE__ && window.__API_BASE__.length) return window.__API_BASE__.replace(/\/+$/,'');
        const m = document.querySelector('meta[name="api-base"]');
        if (m && m.content) return m.content.replace(/\/+$/,'');
        return "";
    }
    function api(p){ return (base() + (p.startsWith("/")?"":"/") + p); }

    // Función para mostrar un mensaje temporal de éxito/error en la pantalla
    function showMessage(message, isError = false) {
        // En una aplicación real, se usaría un modal o un toast para esto
        alert(message);
    }

    // Función para cargar las cuentas de correo en el selector
    async function loadAccounts() {
        try {
            const response = await fetch(api("/get_accounts"));
            if (!response.ok) throw new Error("Error al obtener las cuentas.");
            const accounts = await response.json();
            const selector = document.getElementById("emailAccountSelector");
            selector.innerHTML = "";
            if (accounts.length > 0) {
                accounts.forEach(account => {
                    const option = document.createElement("option");
                    option.value = account;
                    option.textContent = account;
                    selector.appendChild(option);
                });
            } else {
                selector.innerHTML = "<option disabled selected>No se encontraron cuentas.</option>";
            }
        } catch (error) {
            console.error("Error cargando cuentas:", error);
            const selector = document.getElementById("emailAccountSelector");
            selector.innerHTML = "<option disabled selected>Error al cargar cuentas.</option>";
        }
    }

    // Función para cargar la tabla de contratos desde el backend
    async function loadTable() {
        try {
            const response = await fetch(api("/get_table_html"));
            if (!response.ok) throw new Error("Error al obtener la tabla.");
            const tableHtml = await response.text();
            const tbody = document.querySelector("#consolidatedTable tbody");
            tbody.innerHTML = tableHtml;
            // Actualiza el contador de contratos
            const rowCount = tbody.querySelectorAll("tr").length;
            document.getElementById("recordCount").textContent = `${rowCount} contratos cargados`;
        } catch (error) {
            console.error("Error al cargar la tabla:", error);
            const tbody = document.querySelector("#consolidatedTable tbody");
            tbody.innerHTML = `<tr><td colspan="7" class="table-empty-message text-center">Error al cargar datos.</td></tr>`;
        }
    }

    document.addEventListener("DOMContentLoaded", () => {
        // Carga las cuentas de correo al iniciar la página
        loadAccounts();
    });

    // Evento que se dispara al seleccionar un archivo
    document.getElementById("fileInput").addEventListener("change", async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append("file", file);

        try {
            // Envía el archivo al backend para su procesamiento
            const response = await fetch(api("/upload_docx"), {
                method: "POST",
                body: formData,
            });

            if (response.ok) {
                // Si el archivo se subió y procesó correctamente, carga la tabla
                showMessage("Archivo procesado con éxito.");
                await loadTable();
            } else {
                showMessage("Error al procesar el archivo.", true);
            }
        } catch (error) {
            console.error("Error durante la subida del archivo:", error);
            showMessage("Error durante la subida del archivo.", true);
        }
    });

    // Evento para enviar el formulario del modal
    document.getElementById("addAccountForm").addEventListener("submit", async (event) => {
        event.preventDefault(); // Evita el envío por defecto del formulario

        const identifier = document.getElementById("accountIdentifier").value;
        const email = document.getElementById("accountEmail").value;
        const password = document.getElementById("accountPassword").value;
        const signature = document.getElementById("accountSignature").value;

        // Cierra el modal después de obtener los datos
        const myModal = bootstrap.Modal.getInstance(document.getElementById('addAccountModal'));
        if (myModal) myModal.hide();
        
        try {
            const response = await fetch(api("/add_account"), {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ identifier, email, password, signature }),
            });

            if (response.ok) {
                showMessage("Cuenta añadida con éxito!");
                await loadAccounts(); // Recarga el selector de cuentas
            } else {
                showMessage("Error al añadir la cuenta.", true);
            }
        } catch (error) {
            console.error("Error al añadir la cuenta:", error);
            showMessage("Error al añadir la cuenta.", true);
        }
    });

    // Evento para enviar correos
    document.getElementById("btnSendEmails").addEventListener("click", async () => {
        try {
            const selector = document.getElementById("emailAccountSelector");
            const account = selector.value;
            if (account) {
                const response = await fetch(api(`/send_emails?account=${encodeURIComponent(account)}`), { method: "POST" });
                if (response.ok) {
                    showMessage(`Correos enviados con éxito usando la cuenta: ${account}`);
                } else {
                    showMessage("Error al enviar correos.", true);
                }
            } else {
                showMessage("Por favor, selecciona una cuenta de correo.", true);
            }
        } catch (error) {
            console.error("Error al enviar correos:", error);
            showMessage("Error al enviar correos.", true);
        }
    });
</script>
</body>
</html>
"""

# Crea el archivo de plantilla principal
with open(os.path.join(TEMPLATES_DIR, "index.html"), "w", encoding="utf-8") as f:
    f.write(html_content)

# Crea un archivo placeholder para config.js
with open(os.path.join(STATIC_DIR, "config.js"), "w") as f:
    f.write("window.__API_BASE__ = '';")

# Define un fragmento de plantilla para las filas de la tabla
table_rows_html = """
{% if rows %}
    {% for row in rows %}
        <tr>
            <td class="text-center">{{ row.code }}</td>
            <td>{{ row.name }}</td>
            <td>{{ row.position }}</td>
            <td class="text-center">{{ row.entry_date }}</td>
            <td class="text-center">{{ row.contract }}</td>
            <td>{{ row.to }}</td>
            <td>{{ row.cc }}</td>
        </tr>
    {% endfor %}
{% else %}
    <tr>
        <td colspan="7" class="table-empty-message text-center">
            No se ha encontrado data. Por favor, asegúrese de que el archivo Word cargado es válido.
        </td>
    </tr>
{% endif %}
"""

with open(os.path.join(TEMPLATES_DIR, "table_rows.html"), "w", encoding="utf-8") as f:
    f.write(table_rows_html)

# Monta los archivos estáticos
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Datos de ejemplo que se cargarían al procesar el documento .docx
SAMPLE_ROWS: List[Dict[str, Any]] = [
    {
        "code": "C-001",
        "name": "Juan Perez",
        "position": "Analista de Datos",
        "entry_date": date(2023, 1, 15),
        "contract": "Indefinido",
        "to": "juan.perez@empresa.com",
        "cc": "rrhh@empresa.com",
    },
    {
        "code": "C-002",
        "name": "Maria Lopez",
        "position": "Diseñadora UX",
        "entry_date": date(2022, 11, 1),
        "contract": "Temporal",
        "to": "maria.lopez@empresa.com",
        "cc": "jefe.proyecto@empresa.com",
    },
]

# Modelo para la nueva cuenta de correo. Ahora incluye el campo de firma.
class NewAccount(BaseModel):
    identifier: str
    email: str
    password: str
    signature: Optional[str] = None # Nuevo campo, es opcional

@app.get("/", response_class=HTMLResponse, tags=["Páginas"])
async def read_root(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "api_base": ""}
    )

@app.get("/get_accounts", tags=["API"])
async def get_accounts(request: Request):
    return request.app.state.get_accounts()

@app.post("/upload_docx", tags=["API"])
async def upload_docx(request: Request, file: UploadFile = File(...)):
    print(f"Recibiendo archivo: {file.filename}")
    try:
        contents = await file.read()
        print(f"Archivo de {len(contents)} bytes procesado.")
        
        # En una aplicación real, aquí usarías 'python-docx' para leer el archivo.
        
        # Aquí asignamos los datos de ejemplo al estado de la aplicación
        request.app.state.set_rows(SAMPLE_ROWS)
        return {"message": "Archivo procesado con éxito"}
    except Exception as e:
        print(f"Error procesando el archivo: {e}")
        raise HTTPException(status_code=500, detail="Error al procesar el archivo DOCX.")

@app.post("/add_account", tags=["API"])
async def add_account(request: Request, account: NewAccount):
    print(f"Añadiendo nueva cuenta: {account.email}, identificador: {account.identifier}, firma: {account.signature}")
    request.app.state.add_account(account.email)
    return {"message": f"Cuenta {account.identifier} añadida con éxito."}

@app.get("/get_table_html", tags=["API"])
async def get_table_html(request: Request):
    rows = request.app.state.get_rows()
    return templates.TemplateResponse(
        "table_rows.html",
        {"request": request, "rows": rows}
    )

@app.post("/send_emails", tags=["API"])
async def send_emails(request: Request, account: str):
    if account not in request.app.state.get_accounts():
        raise HTTPException(status_code=400, detail="Cuenta de correo no válida")
    
    print(f"Enviando correos usando la cuenta: {account}")
    return {"message": "Correos enviados con éxito"}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
