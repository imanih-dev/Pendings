from app.config import config
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import uvicorn
import os
import random

app = FastAPI()
templates = Jinja2Templates(directory=config.vars.ui_html)

# Datos de prueba
ACCOUNTS = ["correo.ejemplo@empresa.com", "recursos.humanos@empresa.com", "gerencia@empresa.com"]

def get_dummy_rows():
    """Genera una lista de datos de contrato de ejemplo."""
    data = []
    for i in range(random.randint(5, 15)):
        code = f"CODE{random.randint(100, 999)}"
        name = f"Nombre Apellido{i+1}"
        position = random.choice(["Gerente", "Analista", "Asistente", "Especialista"])
        entry_date = f"2023-01-0{i+1}"
        contract = f"Contrato-{code}"
        to = f"email.ejemplo{i+1}@correo.com"
        cc = f"jefe.ejemplo{i+1}@correo.com"
        data.append({
            "code": code,
            "name": name,
            "position": position,
            "entry_date": entry_date,
            "contract": contract,
            "to": to,
            "cc": cc
        })
    return data

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    """Renderiza la página HTML con datos iniciales."""
    return templates.TemplateResponse("index.html", {"request": request, "rows": [], "accounts": []})

@app.post("/load_word_file")
def load_word_file(path: str):
    """Endpoint para cargar archivos de Word. Devuelve un estado vacío."""
    return {"status": "ok"}

@app.get("/get_accounts")
def get_accounts():
    """Devuelve la lista de cuentas de correo de prueba."""
    return ACCOUNTS

@app.get("/get_table")
def get_table():
    """Devuelve la tabla de datos de prueba."""
    return get_dummy_rows()

@app.post("/send_emails")
def send_emails(account: str):
    """Endpoint para enviar correos. Devuelve un estado vacío."""
    return {"status": "ok"}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8080)
