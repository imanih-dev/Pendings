from typing import *
from pydantic import *

from requests import Response

import requests

def handle_response(response: Response):
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Error {response.status_code}: {response.text}")

class BackendHandler:
    def __init__(self, host: IPvAnyAddress, port: PositiveInt):
        self.base_url = f"http://{host}:{port}"

    def get_available_accounts(self):
        url = f"{self.base_url}/all-accounts"

        return handle_response(requests.get(url))

    def set_manifests_dir(self, path: DirectoryPath):
        url = f"{self.base_url}/set-dir"

        return handle_response(requests.post(url, json={"path": path}))
        
    def send_emails(self):
        url = f"{self.base_url}/run"

        return handle_response(requests.post(url))