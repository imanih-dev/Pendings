from typing import *
from pydantic import *

from app.core.backend_handler import BackendHandler
from app.config import config

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import duckdb
import numpy as np
import os
import pandas as pd

QUERY_NEW_HIRING = """
SELECT DISTINCT 
    e.co_trab AS worker_code, 
    TRIM(REPLACE(r.de_area, 'REGION ', '')) AS region,
    CONCAT(TRIM(p.no_trab), ' ', TRIM(p.no_apel_pate), ' ', TRIM(p.no_apel_mate)) AS fullname,
    TRIM(c.de_pues_trab) AS job,
    IIF(s.de_sede LIKE '%REGIONAL%', a.de_unid, s.de_sede) AS agency, 
    TRIM(e.co_tipo_cont) AS contract_t_code,
    TRIM(h.de_secc) AS section,
    e.fe_ingr_empr AS hiring_dt,
    IIF(TRIM(e.co_form_ingr) = 'REI', 1, 0) AS is_rehire,
    i.nu_docu_iden AS dni, 
    TRIM(LOWER(p.NO_DIRE_MAI1)) to
FROM tmtrab_pers p
LEFT OUTER JOIN tmtrab_empr e ON p.co_trab = e.co_trab
LEFT OUTER JOIN ttpues_trab c ON e.co_pues_trab = c.co_pues_trab
LEFT OUTER JOIN tmunid_empr a ON e.co_unid = a.co_unid 
LEFT OUTER JOIN ttsede s ON e.co_sede = s.co_sede 
LEFT OUTER JOIN ttarea r ON e.co_area = r.co_area AND e.co_depa = r.co_depa 
LEFT OUTER JOIN ttsecc h ON e.co_secc = h.co_secc AND e.co_depa = h.co_depa AND e.co_area = h.co_area 
LEFT OUTER JOIN ttdepa d ON e.co_depa = d.co_depa 
LEFT OUTER JOIN ttplan l ON e.co_plan = l.co_plan 
LEFT OUTER JOIN ttmoti_sepa n ON e.co_moti_sepa = n.co_moti_sepa 
LEFT OUTER JOIN tdiden_trab i ON p.co_trab = i.co_trab AND ti_docu_iden = 'DNI'
LEFT OUTER JOIN tdlice_trab m ON p.co_trab = m.co_trab AND co_tipo_lice = 'SPP'
WHERE 
    TRIM(e.ti_situ) = 'ACT' AND 
    TRIM(e.co_form_ingr) <> 'NA' AND 
    TRIM(LOWER(p.NO_DIRE_MAI1)) NOT LIKE '%@cajaarequipa.pe' AND 
    e.fe_ingr_empr >= GETDATE();
"""

def get_connection_chain():
    addr = os.environ.get("OFIPLAN_DB_ADDR")
    username = os.environ.get("OFIPLAN_DB_USERNAME")
    password = os.environ.get("OFIPLAN_DB_PASSWORD")
    db_name = os.environ.get("OFIPLAN_DB_DBNAME")

    return f"mssql+pymssql://{username}:{password}@{addr}/{db_name}"

def query_sql_server(query: str) -> pd.DataFrame:
    engine = create_engine(get_connection_chain())
    
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        return pd.read_sql_query(query, con=engine)
    finally:
        session.close()
        engine.dispose()

class DataBaseHandler:
    def __init__(self):
        self.setup()

    def setup(self):
        self.new_hiring_df: pd.DataFrame = None
        self.input_mem: List[str] = []
        self.lookup_dfs = {}

    def flush_memory(self):
        self.setup()

        for k, (path, rename_cols) in config.vars.lookup_tables.items():
            df = pd.read_excel(path)

            if rename_cols:
                df.rename(columns=rename_cols, inplace=True)

            conn = duckdb.connect(":memory:")
            conn.register("temp_df", df)

            self.lookup_dfs[k] = conn.sql("SELECT * FROM temp_df").df()

            conn.close()

    def load_NEW_HIRING(self):
        self.new_hiring_df = query_sql_server(QUERY_NEW_HIRING)

    def consolidate(self):
        self.load_NEW_HIRING()

        hiring_with_bps = pd.merge(left=self.new_hiring_df, right=self.lookup_dfs.get("BPS"), how="left", on="region")
        df_main = pd.merge(left=hiring_with_bps, right=self.lookup_dfs.get("EMA"), how="left", on="agency")

        df_main["more_emails"] = np.select([
            (df_main["job"].str.contains("ANALISTA", case=False)) & (df_main["section"] == "CREDITOS"),
            (df_main["job"].str.contains("REPRESENTANTE DE SERVICIO", case=False))
        ], [
            df_main["adm"], 
            df_main["ao"]
        ], default=None)

        df_main = df_main.drop(columns=["adm", "ao"])

        df_main = pd.merge(left=df_main, right=self.lookup_dfs.get("AGA"), how="left", on=["agency", "region"])
        df_main = pd.merge(left=df_main, right=self.lookup_dfs.get("TPE"), how="left", on="job")
        df_main = pd.merge(left=df_main, right=self.lookup_dfs.get("JMO"), how="left", on="job")

        df_main["cc"] = df_main["bp_emails"].fillna("") + ", " + df_main["more_emails"].fillna("")
        df_main["cc"] = df_main["cc"].str.strip(", ").replace("", None)

        df_main.drop(columns=["emails_bp", "emails_ags"], inplace=True)

        return df_main
        