from typing import *
from pydantic import *

from app.core.database_handler import DataBaseHandler
from app.core.pdf_splitter_handler import PdfSplitterHandler
from app.core.backend_handler import BackendHandler
from app.backend import run_backend

from app.mail.build_manifest import build_email_manifest
from app.config import config

from joblib import Memory
import os
import pandas as pd

MONTHS_VERBOSE = [
    "Enero", "Febrero", "Marzo", "Abril", 
    "Mayo", "Junio", "Julio", "Agosto", 
    "Setiembre", "Octubre", "Noviembre", "Diciembre"
]

mem = Memory(config.cachedir, verbose=0)

@mem.cache
def get_cached_account(account_name: Optional[str] = None):
    if account_name is None:
        return None
    return account_name

class BotContractKernel:
    def __init__(self, host: IPvAnyAddress):
        self.db_handler = DataBaseHandler()

        self.process_pid, backend_port = run_backend(host=host)

        self.back_handler = BackendHandler(host, backend_port)

        self.setup()

    def setup(self):
        self.pdf_chunks_mapped: Dict[str, Any] = {}
        self.hiring_df: pd.DataFrame = None
        self.dispatch_account = None
        self.back_handler.set_manifests_dir(config.vars.manifests_input_dir)

    def flush_memory(self):
        self.setup()

        self.db_handler.flush_memory()
    
    def set_email_dispatch_account(self, account_name: Optional[str] = None):
        self.dispatch_account = get_cached_account(account_name)

    def load_input_docx(self, file_path: FilePath):
        splitter = PdfSplitterHandler(file_path, r"\b\d{11}\b")

        self.pdf_chunks_mapped = splitter.run_splits()

    def load_hiring_data(self):
        self.hiring_df = self.db_handler.consolidate()

    def build_firstsend_emails(self):
        if self.hiring_df is not None and self.pdf_chunks_mapped and self.dispatch_account is not None:
            chunks_df = pd.DataFrame.from_dict(self.pdf_chunks_mapped, orient="index", columns=["contract_pdf_path"])
            chunks_df = chunks_df.reset_index().rename(columns={"index": "worker_code"})

            merged_df = pd.merge(left=chunks_df, right=self.hiring_df, how="left", on="worker_code")

            for row in merged_df.itertuples(index=False):
                contract_filename = str(row.fullname).upper() + f"_{row.hiring_dt.strftime("%d.%m.%Y")}.pdf"
                manual_filename = os.path.basename(config.vars.manual_pdf)

                build_email_manifest(
                    manifest_temp_key="mailzero",
                    header_data={
                        "account_name": self.dispatch_account,
                        "to_recipients": [to.strip() for to in row.to.split(",")],
                        "cc_recipients": [cc.strip() for cc in row.cc.split(",")],
                        "attachments": [
                            {
                                "file_path": row.contract_pdf_path,
                                "filename": contract_filename
                            },
                            {
                                "file_path": config.vars.manual_pdf,
                                "filename": manual_filename
                            }
                        ],
                        "use_signature": True
                    },
                    body_format_data={
                        "fullname_M": str(row.fullname).upper(),
                        "fullname": str(row.fullname).title(),
                        "month_year": f"{MONTHS_VERBOSE[row.hiring_dt.month - 1]} {row.hiring_dt.year}",
                        "contract_filename": contract_filename,
                        "manual_filename": manual_filename
                    }
                )

    def send_emails(self):
        self.back_handler.send_emails()


