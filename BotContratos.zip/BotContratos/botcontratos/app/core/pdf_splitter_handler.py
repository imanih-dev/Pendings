from typing import *
from pydantic import *

from app.config import config

from PyPDF2 import PdfReader, PdfWriter

import docx2pdf
import io
import os
import re
import uuid

class PdfSplitterHandler:
    def __init__(self, docx_file: FilePath, regex_pattern: str):
        self.pdf_base = self.__convert_docx_to_pdf(docx_file)
        self.regex_pattern = regex_pattern

    def __convert_docx_to_pdf(self, docx_file: FilePath):
        try:
            output_buffer = io.BytesIO()
            
            docx2pdf.convert(docx_file, output_buffer)
            output_buffer.seek(0)
            
            return output_buffer
            
        except Exception as error:
            print(f"Error converting DOCX to PDF: {error}")
            return None

    def extract_text_from_pdf(self):
        try:
            reader = PdfReader(stream=self.pdf_base)
            text = ""
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"

            return text
        except Exception:
            return ""

    def find_codes_in_text(self, text: str):
        matches = re.findall(self.regex_pattern, text)
        return list(set(matches))

    def split_pdf_into_chunks(self):
        reader = PdfReader(stream=self.pdf_base)
        os.makedirs(config.vars.pdf_chunks_dir, exist_ok=True)
        
        code_to_path = {}
        current_writer = PdfWriter()
        last_found_code = None

        def save_chunk(code, writer):
            if not writer.pages:
                return
            chunk_path = os.path.join(
                config.vars.pdf_chunks_dir, 
                f"{uuid.uuid4().hex[:8]}_{code}.pdf"
            )
            with open(chunk_path, "wb") as f_out:
                writer.write(f_out)
            code_to_path[code] = chunk_path

        for page in reader.pages:
            text = page.extract_text()
            match = re.search(self.regex_pattern, text)
            found_code = match.group(0) if match else last_found_code
            
            if found_code and found_code != last_found_code:
                save_chunk(last_found_code, current_writer)
                current_writer = PdfWriter()
            
            if found_code:
                last_found_code = found_code
            
            if last_found_code:
                current_writer.add_page(page)

        save_chunk(last_found_code, current_writer)
        return code_to_path

    def run_splits(self):
        full_text = self.extract_text_from_pdf(self.pdf_base)
        self.pdf_base.seek(0)

        codes = self.find_codes_in_text(full_text)
        
        if not codes:
            return {}

        code_to_path = self.split_pdf_into_chunks(self.pdf_base)

        return code_to_path