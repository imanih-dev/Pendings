from typing import *

from app.config import config

import frontmatter

def build_email_manifest(manifest_temp_key: str, header_data: Dict[str, Any], 
                         body_format_data: Dict[str, Any]):
    input_path = config.vars.email_templates.get(manifest_temp_key)
    output_path = config.vars.manifests_input_dir

    if input_path is not None:
        post = frontmatter.load(input_path)
        
        post.metadata.update(header_data)
        post.content = post.content.format(**body_format_data)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(frontmatter.dumps(post))