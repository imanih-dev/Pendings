from typing import *
from pydantic import *

from dotenv import load_dotenv
from pydantic import BaseModel

import json
import os
import sys

def load_json(filepath: str):
    with open(filepath, 'r') as file:
        return json.load(file)
    
def write_json(filepath: str, data: Dict[str, Any]):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w') as file:
        json.dump(data, file, indent=4)

class EnvironmentVariables(BaseModel):
    ui_html: DirectoryPath
    manifests_input_dir: DirectoryPath
    manual_pdf: FilePath
    pdf_chunks_dir: DirectoryPath
    email_templates: Dict[str, FilePath]
    lookup_tables: Dict[str, Tuple[FilePath, List[str]]]

class ConfigSettings:
    def __init__(self):
        if getattr(sys, 'frozen', False):
            self.base_dir = os.path.dirname(sys.executable)
        else:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = current_dir

            while True:
                if os.path.exists(os.path.join(project_root, ".env")) or \
                   os.path.exists(os.path.join(project_root, ".git")):
                    self.base_dir = project_root
                    break
                parent_dir = os.path.dirname(project_root)
                if parent_dir == project_root:
                    self.base_dir = current_dir
                    break
                project_root = parent_dir

        dotenv_path = os.path.join(self.base_dir, ".env")
        load_dotenv(dotenv_path, override=True)
        
        self.reload()

    def reload(self):
        self.cachedir = str(os.environ["CACHEDIR"]).format(base_dir=self.base_dir)

        self.vars = EnvironmentVariables(
            ui_html = str(os.environ["PATH_UI_HTML"]).format(base_dir=self.base_dir),
            manifests_input_dir = str(os.environ["DIRPATH_MANIFESTS_INPUT"]).format(base_dir=self.base_dir),
            manual_pdf = str(os.environ["PATH_MANUAL_PDF"]).format(base_dir=self.base_dir),
            pdf_chunks_dir = str(os.environ["DIRPATH_PDF_CHUNKS"]).format(base_dir=self.base_dir),
            email_templates = {
                "mailzero": str(os.environ["PATH_MD_EMAILTEMP_FIRST_ADVICE"]).format(base_dir=self.base_dir)
            },
            lookup_tables = {
                "BPS": (str(os.environ["PATH_XLSX_BPS"]).format(base_dir=self.base_dir), ["region", "bp_emails"]),
                "EMA": (str(os.environ["PATH_XLSX_EMA"]).format(base_dir=self.base_dir), ["agency", "adm", "ao"]),
                "TPE": (str(os.environ["PATH_XLSX_TPE"]).format(base_dir=self.base_dir), ["job", "test_period"]),
                "JMO": (str(os.environ["PATH_XLSX_JMO"]).format(base_dir=self.base_dir), ["job", "modality"]),
                "AGA": (str(os.environ["PATH_XLSX_AGA"]).format(base_dir=self.base_dir), ["agency", "region", "inception_date"])
            }
        )

config = ConfigSettings()