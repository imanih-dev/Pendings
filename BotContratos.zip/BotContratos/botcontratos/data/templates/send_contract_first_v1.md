---
subject: 🏢 ¡Bienvenido(a) a la familia Caja Arequipa! {fullname_M} - SE REMITE TU CONTRATO DE TRABAJO ({month_year})
---

<div style="border-left: 4px solid #1f4e79; padding-left: 15px; margin-bottom: 20px;">
<h3 style="color: #1f4e79; margin-top: 0;">🎉 ¡Bienvenido(a), {fullname}!</h3>
<h4 style="color: #2e5c8a; margin-top: 0;">👋 Estamos muy entusiasmados de que te unas al Equipo de Caja Arequipa.</h4>
</div>

- Adjunto al presente correo encontrará su <u>contrato de trabajo</u> (<span style="color: #c5504b; background-color: #fff2f0; padding: 2px 6px;">**{contract_filename}**</span>) para su revisión y suscripción.

- Por favor, seguir las instrucciones indicadas en el <u>manual adjunto</u> de este correo (<span style="color: #c5504b; background-color: #fff2f0; padding: 2px 6px;">**{manual_filename}**</span>) para la firma y remisión del contrato escaneado. 

<table style="border: 2px solid #d68910; background-color: #fef9e7; width: 100%; margin: 15px 0;" cellpadding="10">
<tr><td>
📅 <b>FECHA LÍMITE:</b> Tendrá hasta el <span style="color: #d68910;"><u><b>{hiring_dt}</b></u></span> para enviar su respuesta con el contrato firmado y escaneado.
</td></tr>
</table>

<div style="border-left: 4px solid #1f4e79; padding-left: 15px; margin: 25px 0;">
<h3 style="color: #1f4e79; margin-top: 0;">👥 Estimado Gerente de Agencia / Jefe de Plataforma / Jefe Inmediato:</h3>
</div>

<table style="background-color: #fff5f5; border: 1px solid #fed7d7; width: 100%; margin-bottom: 20px;" cellpadding="15">
<tr><td>
⚠️ <b>IMPORTANTE:</b> De no efectuar la firma del contrato el colaborador en la fecha indicada por razones de desistimiento, renuncia u otras causales, sírvase comunicar inmediatamente a los siguientes correos y realizar el seguimiento respectivo:
<ul>
  <li>
    <b>Ceses de Personal:</b> cesesdepersonal@cajaarequipa.pe
  </li>
  <li>
    <b>Control Asistencia:</b> ControlAsistencia@cajaarequipa.pe
  </li>
</ul>
</td></tr>
</table>

<div style="margin-top: 30px; padding-top: 15px; border-top: 1px solid #e9ecef;">
<b>Atte.</b><br>
<em style="color: #6c757d;">Equipo de Relaciones Laborales</em><br>
<em style="color: #6c757d;">Caja Arequipa</em>
</div>