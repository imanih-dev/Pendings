---
subject: ¡Recordatorio! - Nuevo contrato {month_year} para {fullname}
interval_as_seconds: 3600
---

Estimado colaborador,

POR FAVOR EMITE TU CORREO CON TU CONTRATO FIRMADO.

**Recuerda la fecha límite**: {limit_dt}

Asegúrese de cumplir con los siguientes requisitos:
- Responder en el hilo de correo original que lleva el siguiente asunto: 
```
"NUEVO CONTRATO AGOSTO 2025 | CACERES VELA BRUCE | 11-08-2025" 
```
o enviar un nuevo correo a botcontratos@cajaarequipa.pe y contratoslaborales@cajaarequipa.pe con el siguiente asunto: 
```
"NUEVO CONTRATO AGOSTO 2025 | CACERES VELA BRUCE | 11-08-2025".
```
- Adjuntar solo 1 archivo PDF (contrato firmado y escaneado) con 5 páginas.
Si hiciste llegar tu contrato firmado por algún encargado OMITE este correo. 
