from typing import *
from pydantic import *

import pandas as pd

class DataBaseHandler:
    def __init__(self):
        self.flush_memory()

    def flush_memory(self):
        self.btt_df: pd.DataFrame = None

    def load_RCT_CMAC(self, excel_path: FilePath):
        self.btt_df = pd.read_excel(
            excel_path,
            header=7, 
            usecols="B:G", 
        )
        
        new_column_names = [
            "dni",
            "fullname",      
            "num_operation",
            "num_account",
            "credit_type",
            "timestamp"   
        ]
        
        self.btt_df.columns = new_column_names
        
        self.btt_df["dni"] = self.btt_df["dni"].astype(str).str.strip()
        self.btt_df["num_operation"] = self.btt_df["num_operation"].astype(str).str.strip()
        self.btt_df["num_account"] = self.btt_df["num_account"].astype(str).str.strip()
        self.btt_df["timestamp"] = pd.to_datetime(self.btt_df["timestamp"], format="mixed")
        
        required_cols = ["dni", "num_operation", "num_account", "timestamp"]
        self.btt_df = self.btt_df[required_cols]

    def merge_data(self, input_df: pd.DataFrame):
        if self.btt_df is not None:
            merged_df = pd.merge(left=input_df, right=self.btt_df, how="left", on="dni")

            return merged_df
