from typing import *
from pydantic import *

from app.core.models import Employee_AyCdT_Register
from app.core.database_handler import DataBaseHandler
from app.core.backend_handler import BackendHandler
from app.backend import run_backend

#from app.mail.build_manifest import build_email_manifest
from app.config import config

import pandas as pd

class BotAyCdTKernel:
    def __init__(self, host: IPvAnyAddress):
        self.db_handler = DataBaseHandler()

        #self.process_pid, backend_port = run_backend(host=host)

        self.back_handler = BackendHandler(host, 8000)#backend_port)

        self.setup()

    def setup(self):
        self.input_mem: List[Employee_AyCdT_Register] = []
        self.dispatch_account = None

        #self.back_handler.set_manifests_dir(config.vars.manifests_input_dir)

    def flush_memory(self):
        self.setup()

        self.db_handler.flush_memory()
    
    def set_email_dispatch_account(self, account_name: Optional[str] = None):
        self.dispatch_account = account_name

    def load_db_excel(self, file_path: FilePath):
        self.db_handler.load_RCT_CMAC(file_path)

    def add_employee_register(self, reg_dict: Dict[str, Any]):
        try:
            register = Employee_AyCdT_Register.model_validate(reg_dict)

            self.input_mem.append(register)
        except Exception as error:
            print(f"Error: {error}")

    def build_emails(self):
        if self.dispatch_account is not None:

            input_df = pd.DataFrame([reg.model_dump() for reg in self.input_mem])
            merged_df = self.db_handler.merge_data(input_df)

            credit_accounts = merged_df.groupby(by="is_caja")

            for is_caja, main_group in credit_accounts:
                for dni, credit_df in main_group.groupby(by="dni"):
                    count_rows = len(credit_df)
                    if is_caja:
                        print("dni", count_rows)
                        self.back_handler.call_build_email_from_md()
                    else:
                        print("eind", count_rows)
                    continue
                    """build_email_manifest(
                        manifest_temp_key="mailzero",
                        header_data={
                            "account_name": self.dispatch_account,
                            "to_recipients": [to.strip() for to in row.to.split(",")],
                            "cc_recipients": [cc.strip() for cc in row.cc.split(",")],
                            "use_signature": True
                        },
                        body_format_data={
                            "fullname": str(row.fullname).upper(),
                        }
                    )"""

    def send_emails(self):
        self.back_handler.send_emails()
