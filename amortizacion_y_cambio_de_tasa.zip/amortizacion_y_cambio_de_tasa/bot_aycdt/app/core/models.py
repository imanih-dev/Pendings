from pydantic import *

class Employee_AyCdT_Register(BaseModel):
    dni: str
    fullname: str
    is_caja: StrictBool
    amount: PositiveFloat