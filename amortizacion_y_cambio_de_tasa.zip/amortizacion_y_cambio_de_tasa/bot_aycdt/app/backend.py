import socket
import subprocess
import sys

def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        s.listen(1)
        return s.getsockname()[1]

def run_backend(executable_path: str, host: str = "127.0.0.1"):
    port = find_free_port()

    process = subprocess.Popen(
        [executable_path, "--host", host, "--port", str(port)],
        stdout=sys.stdout,
        stderr=sys.stderr
    )

    return process, port