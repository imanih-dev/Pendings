import uvicorn
from fastapi import FastAPI
from contextlib import asynccontextmanager
import os
import json
import socket
import platform

def get_appdata_path():
    if platform.system() == "Windows":
        return os.getenv('LOCALAPPDATA')
    elif platform.system() == "Darwin":
        return os.path.join(os.path.expanduser('~'), 'Library', 'Application Support')
    else:
        return os.path.join(os.path.expanduser('~'), '.local', 'share')

APP_DIR_NAME = "MiEmpresa/MiApp"
APP_DATA_PATH = os.path.join(get_appdata_path(), APP_DIR_NAME)
API_STATUS_FILE_PATH = os.path.join(APP_DATA_PATH, "api_status.json")

def find_available_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', 0))
    port = s.getsockname()[1]
    s.close()
    return port

def update_api_status_file(api_name, host, port, is_active):
    os.makedirs(APP_DATA_PATH, exist_ok=True)
    try:
        with open(API_STATUS_FILE_PATH, "r") as f:
            api_status_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        api_status_data = {}
    
    api_status_data[api_name] = {
        "host": host,
        "port": port,
        "is_active": is_active
    }
    
    with open(API_STATUS_FILE_PATH, "w") as f:
        json.dump(api_status_data, f, indent=4)

@asynccontextmanager
async def lifespan(app: FastAPI):
    API_NAME = "mail-dispatch-api"
    HOST = "127.0.0.1"
    port = app.state.port
    
    update_api_status_file(API_NAME, HOST, port, True)
    
    yield
    
    update_api_status_file(API_NAME, HOST, port, False)

API_PORT = find_available_port()
app = FastAPI(lifespan=lifespan)
app.state.port = API_PORT

@app.get("/")
def read_root():
    return {"message": "API de correo activa y lista."}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=API_PORT)