from app.core.kernel import BotAyCdTKernel

if __name__ == "__main__":
    kernel = BotAyCdTKernel("127.0.0.1")

    kernel.load_db_excel(r"C:\Users\imamanih\Documents\REPORTE BANTOTAL.xlsx")

    kernel.add_employee_register({
        "dni": "45100327",
        "fullname": "MAMANI LAURA ADDERLY ARTURO",
        "is_caja": True,
        "amount": 4857.33
    })

    kernel.add_employee_register({
        "dni": "29581732",
        "fullname": "ABARCA ZEGARRA KELLY PATRICIA",
        "is_caja": False,
        "amount": 3223.77
    })

    kernel.set_email_dispatch_account("abc")

    kernel.build_emails()