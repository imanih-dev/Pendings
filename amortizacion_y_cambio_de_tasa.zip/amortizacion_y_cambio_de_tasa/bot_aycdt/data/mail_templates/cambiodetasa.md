---
subject: Cambio de tasa  de Crédito Caja Arequipa - {fullname}
---
*Estimadas Buena tarde,*

Por medio del presente se solicita el cambio de tasa correspondiente al ex trabajador (a) **ENCALADA LLUNCO KATHERINE** se indica:  

%*{- Cambio de Tasa de crédito N° **{operation_number} CUENTA CLIENTE {client_account}.**}

Le agradeceré **HACER** el cambio de tasa del trabajador CMAC según corresponda, conforme lo señala el procedimiento de créditos otorgados a trabajadores CMAC, así como enviar el nuevo cronograma de pagos.
