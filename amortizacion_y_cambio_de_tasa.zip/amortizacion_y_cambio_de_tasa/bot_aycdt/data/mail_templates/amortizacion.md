---
subject: Amortización de crédito y Cambio de tasa Caja Arequipa - {fullname}
---
*Estimados Buena tarde,*

Por medio del presente se solicita la amortización de crédito correspondiente al ex trabajador (a) **{fullname}**. Como se indica:
- Amortización del Crédito Personal Nº **{operation_number}** por **S/ {amount}** CUENTA CLIENTE **{client_account}**.
 
Debido a que dicho importe se ha descontado en su Liquidación de Beneficios Sociales. Le agradeceré **HACER** el cambio de tasa del trabajador CMAC según corresponda, conforme lo señala el procedimiento de créditos otorgados a trabajadores CMAC, así como enviar el nuevo cronograma de pagos.